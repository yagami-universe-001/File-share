━━━━━━━━━━━━━━━━━━━━

<h2 align="center">
    ──「 ғɪʟᴇ sᴛᴏʀᴇ ᴘʀᴏ - ʙʏ ʏᴀᴛᴏ 」──
</h2>

<p align="center">
  <img src="https://camo.githubusercontent.com/6cfe41b279bbe53061fc4591d115038dc36acc593bb6062d0692b8a0810d1bde/68747470733a2f2f74652e6c656772612e70682f66696c652f3066373538333231613932613934323861366334382e6a7067">
</p>

<p align="center">
<a href="https://github.com/codeflix-bots/filestore/stargazers"><img src="https://img.shields.io/github/stars/codeflix-bots/filestore?color=black&logo=github&logoColor=black&style=for-the-badge" alt="Stars" /></a>
<a href="https://github.com/codeflix-bots/filestore/network/members"> <img src="https://img.shields.io/github/forks/codeflix-bots/filestore?color=black&logo=github&logoColor=black&style=for-the-badge" /></a>
<a href="https://github.com/codeflix-bots/filestore/blob/yato/LICENSE"> <img src="https://img.shields.io/badge/License-MIT-blueviolet?style=for-the-badge" alt="License" /> </a>
<a href="https://www.python.org/"> <img src="https://img.shields.io/badge/Written%20in-Python-orange?style=for-the-badge&logo=python" alt="Python" /> </a>
<a href="https://github.com/codeflix-bots/filestore/commits/Noob-Mukesh"> <img src="https://img.shields.io/github/last-commit/codeflix-bots/filestore?color=blue&logo=github&logoColor=green&style=for-the-badge" /></a>
</p>

<p align="center">
<b>𝗗𝗘𝗣𝗟𝗢𝗬𝗠𝗘𝗡𝗧 𝗠𝗘𝗧𝗛𝗢𝗗𝗦</b>
</p>

<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʜᴇʀᴏᴋᴜ 」─
</h3>

<p align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/codeflix-bots/Filestore"> <img src="https://img.shields.io/badge/Deploy%20On%20Heroku-black?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>


<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ᴠᴘs/ʟᴏᴄᴀʟ 」─
</h3>

<details><summary><b> - ғᴇᴀᴛᴜʀᴇs ᴀɴᴅ ᴅᴇᴄʀɪᴘᴛɪᴏɴ:</b></summary>
  
## ғᴇᴀᴛᴜʀᴇs
### ›› ʀᴇǫᴜᴇsᴛ ғᴏʀᴄᴇ sᴜʙ: 
<i>The most demanding aspect is the Request Force-Sub feature. By enabling Request Force-Sub mode, users are provided with a private channel link along with a join request. This feature adds versatility, allowing for greater flexibility in managing Force-Sub channels based on individual preferences. Additionally, the Request Force-Sub settings offer interactive features that enable more advanced and reliable operations.</i>

### ›› ᴄᴜsᴛᴏᴍ ғᴏʀᴄᴇ sᴜʙ: 
<i>You can add one or multiple force-sub channels—there's no limit to the number you can add. You can also empty the list by deleting all force-sub channels. This feature provides versatility, allowing you to create a custom number of force-sub channels according to your preference.</i>

### ›› ᴀᴅᴅ ᴍᴜʟᴛɪ ᴀᴅᴍɪɴs: 
<i>You can add one or multiple admins by providing their user IDs, and you can also remove all admins if needed. Admins have access to some useful bot commands but do not have access to all commands.</i>

### ›› ʙᴀɴ-ᴜɴʙᴀɴ: 
<i>You can add user IDs to a banned list, preventing those who annoy you or spam the bot from using it. They will be unable to access the bot until you remove them from the banned list.</i>

### ›› ᴀᴜᴛᴏ ᴅᴇʟᴇᴛᴇ: 
<i>This feature is crucial for protecting the bot from copyright strikes and reducing the risk of being banned from Telegram. It includes two options: first, you can enable or disable the auto-delete mode; second, you can set a timer, so files will be automatically deleted after a specified period. After that it also send a message that shows the "previous message was deleted" and provide the link to retrieve again the same files.</i>

### ›› ᴄᴏɴᴛᴇɴᴛ ʙᴜᴛᴛᴏɴ: 
<i>This feature allows you to add customizable buttons to files shared by the bot. Every file shared by the bot will have a button, which you can tailor to meet your specific needs.</i>

### ›› sᴇᴛ ʙᴜᴛᴛᴏɴ: 
<i>This feature allows you to customize the content buttons on files shared by the bot. For example, you can set the button name and link. You could create a button labeled "Join Channel," which will appear on the files and contain a specific link provided by you.</i>

### ›› ʜɪᴅᴇ ᴄᴀᴘᴛɪᴏɴ ᴀɴᴅ ᴘʀᴏᴛᴇᴄᴛ ᴄᴀᴘᴛɪᴏɴ:
<i>The "Hide Caption" feature allows you to remove the caption from shared files, while the "Protect Content" feature secures the files. If you enable "Protect Content," the files cannot be forwarded by users.</i>

### ›› sᴛᴀʀᴛ & ғsᴜʙ ᴍᴇᴅɪᴀ:
<i>ᴘʀᴏᴠɪᴅᴇ ɪᴍᴀɢᴇ ᴜʀʟs ᴏʀ ᴅɪʀᴇᴄᴛʟʏ sᴇɴᴅ ᴘʜᴏᴛᴏs ᴛᴏ ᴄᴜsᴛᴏᴍɪᴢᴇ ᴛʜᴇ sᴛᴀʀᴛ ᴀɴᴅ ꜰᴏʀᴄᴇ sᴜʙsᴄʀɪʙᴇ ᴍᴇssᴀɢᴇs.</i>

### ›› ꜰᴜʟʟʏ ᴇᴅɪᴛᴀʙʟᴇ ᴍᴇssᴀɢᴇs:
<i>ᴄᴜsᴛᴏᴍɪᴢᴇ sᴛᴀʀᴛ, ᴀʙᴏᴜᴛ, ʀᴇᴘʟʏ, ᴀɴᴅ ғsᴜʙ ᴍᴇssᴀɢᴇs ᴡɪᴛʜ ꜰᴏʀᴍᴀᴛᴛɪɴɢ ᴀɴᴅ ᴘʟᴀᴄᴇʜᴏʟᴅᴇʀs (sᴇᴇ ʙᴇʟᴏᴡ)..</i>

### ›› ᴄᴜsᴛᴏᴍ ᴜʀʟ sʜᴏʀᴛᴇɴᴇʀ:
<i>ᴀᴅᴅ ʏᴏᴜʀ ꜱʜᴏʀᴛᴇɴᴇʀ ᴜʀʟ, ᴀᴘɪ ᴋᴇʏꜱ, ᴀɴᴅ ᴅɪʀᴇᴄᴛ ᴛᴇʟᴇɢʀᴀᴍ ᴛᴜᴛᴏʀɪᴀʟ ʟɪɴᴋꜱ ꜰᴏʀ ᴇᴀꜱʏ ᴄᴏɴꜰɪɢᴜʀᴀᴛɪᴏɴ...</i>

### <i>›› In addition to the above, more user-friendly and advanced interaction features have been added.</i>
</details>

<details><summary><b> - ᴀᴅᴍɪɴ ᴀɴᴅ ᴜsᴇʀs ᴄᴏᴍᴍᴀɴᴅs :</b></summary>
  
## ᴀᴅᴍɪɴ ᴀɴᴅ ᴜsᴇʀs ᴄᴏᴍᴍᴀɴᴅs
- **start** - sᴛᴀʀᴛ ᴛʜᴇ ʙᴏᴛ
- **shortner** - sʜᴏʀᴛɴᴇʀ sᴇᴛᴛɪɴɢs
- **users** - ᴠɪᴇᴡ ᴛʜᴇ ᴜsᴇʀs ʟɪsᴛ
- **broadcast** - sᴇɴᴅ ᴀ ᴍᴇssᴀɢᴇ ᴛᴏ ᴀʟʟ ᴜsᴇʀs
- **batch** - sᴇɴᴅ ᴍᴇssᴀɢᴇs ɪɴ ʙᴀᴛᴄʜᴇs
- **genlink** - ɢᴇɴᴇʀᴀᴛᴇ ᴀ ʟɪɴᴋ
- **usage** - ᴄʜᴇᴄᴋ ʟɪɴᴋ ᴜsᴀɢᴇ
- **pbroadcast** - sᴇɴᴅ ᴘʀᴇᴍɪᴜᴍ ᴍᴇssᴀɢᴇ ᴛᴏ ᴜsᴇʀs
- **ban** - ʙᴀɴ ᴀ ᴜsᴇʀ
- **unban** - ᴜɴʙᴀɴ ᴀ ᴜsᴇʀ
- **addpremium** - ᴀᴅᴅ ᴘʀᴇᴍɪᴜᴍ ᴜsᴇʀ
- **delpremium** - ʀᴇᴍᴏᴠᴇ ᴘʀᴇᴍɪᴜᴍ ᴜsᴇʀ
- **premiumusers** - ᴠɪᴇᴡ ᴀʟʟ ᴘʀᴇᴍɪᴜᴍ ᴜsᴇʀs
- **request** - sᴇɴᴅ ᴀ ʀᴇǫᴜᴇsᴛ
- **profile** - ᴠɪᴇᴡ ᴜsᴇʀ ᴘʀᴏғɪʟᴇ

- **db** - db channel configs
- **adddb** - add primary & secondary db channel
- **removedb** - to remove db channel.
</details>

<details><summary><b> - ᴠᴀʀɪᴀʙʟᴇs :</b></summary>
  
## ᴠᴀʀɪᴀʙʟᴇs

```python
# Bot Instance Configuration
SESSION = "your_session_name"
TOKEN = "your_bot_token"
API_ID = your_api_id
API_HASH = "your_api_hash"
WORKERS = 5

# Database Configuration
DB_URI = "your_mongodb_uri"
DB_NAME = "your_database_name"

# Force Subscription Channels [channel_id, request_enabled, timer_in_minutes]
FSUBS = [[-1001234567890, True, 10]]

# Database Channel
DB_CHANNEL = -1001234567890

# Auto Delete Timer (seconds)
AUTO_DEL = 300

# Admin IDs
ADMINS = [123456789, 987654321]

# Bot Settings
DISABLE_BTN = True
PROTECT = True

# Messages Configuration
MESSAGES = {
    "START": "Your start message here with {first} placeholder",
    "FSUB": "Your force subscription message",
    "ABOUT": "About message",
    # ... other messages
}
```
</details>

<details>
<summary><h3>
- <b> ᴠᴘs/ʟᴏᴄᴀʟ ᴅᴇᴘʟᴏʏᴍᴇɴᴛ ᴍᴇᴛʜᴏᴅ </b>
</h3></summary>

- Get your [Necessary Variables](https://github.com/Codeflix-Bots/filestore/blob/yato/config.py)
- git clone https://github.com/Codeflix-Bots/filestore
- # Install Packages
- pip3 install -U -r requirements.txt
- Edit config.py with variables as given below then run bot
- python3 main.py

<p align="center">
  <img src="https://graph.org/file/c7727a6d27332ffcd8f03.jpg">
</p>


</details>
━━━━━━━━━━━━━━━━━━━━

<h3 align="center">
    ─「 sᴜᴩᴩᴏʀᴛ 」─
</h3>

<p align="center">
<a href="https://telegram.me/codeflixsupport"><img src="https://img.shields.io/badge/-Support%20Group-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>
<p align="center">
<a href="https://telegram.me/codeflix_bots"><img src="https://img.shields.io/badge/-Support%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>

━━━━━━━━━━━━━━━━━━━━

<h3 align="center">
    ─「 ᴄʀᴇᴅɪᴛs 」─
</h3>

- <b>[ʏᴀᴛᴏ](https://github.com/Codeflix-Bots)  ➻  [sᴏᴍᴇᴛʜɪɴɢ](https://github.com/proyato) </b>
- <b>[ᴠᴏᴀᴛ](https://github.com/Codeflix-Bots)  ➻  [ʙᴀsᴇ ʀᴇᴘᴏ](https://github.com/ArihantSharma/FileStoreBot) </b>

<h3 align="center">
<b>🤝 ᴄᴏɴᴛʀɪʙᴜᴛɪɴɢ
ᴄᴏɴᴛʀɪʙᴜᴛɪᴏɴs ᴀʀᴇ ᴀʟᴡᴀʏs ᴡᴇʟᴄᴏᴍᴇ! ꜰᴇᴇʟ ꜰʀᴇᴇ ᴛᴏ ᴏᴘᴇɴ ᴘᴜʟʟ ʀᴇǫᴜᴇsᴛs ᴛᴏ ɪᴍᴘʀᴏᴠᴇ ᴛʜɪs ʀᴇᴘᴏ 🖤 </b>
</h3>

# 📝 ʟɪᴄᴇɴsᴇ
›› ʏᴏᴜ ᴄᴀɴ ꜰʀᴇᴇʟʏ ʜᴏsᴛ ᴛʜɪs ʀᴇᴘᴏ ʏᴏᴜʀsᴇʟꜰ. ᴀʟʟ ᴡᴇ ᴀsᴋ ɪs ᴛʜᴀᴛ ʏᴏᴜ ᴘʀᴏᴠɪᴅᴇ ᴘʀᴏᴘᴇʀ ᴄʀᴇᴅɪᴛs ʙʏ ʟɪɴᴋɪɴɢ ᴛᴏ ᴛʜɪs ʀᴇᴘᴏsɪᴛᴏʀʏ.

›› ᴛʜɪs ᴘʀᴏᴊᴇᴄᴛ ɪs ʟɪᴄᴇɴsᴇᴅ ᴜɴᴅᴇʀ ᴛʜᴇ ɢɴᴜ ɢᴇɴᴇʀᴀʟ ᴘᴜʙʟɪᴄ ʟɪᴄᴇɴsᴇ ᴠ3.0 (ɢᴘʟᴠ3).
ʏᴏᴜ ᴀʀᴇ ꜰʀᴇᴇ ᴛᴏ ᴜsᴇ, ᴍᴏᴅɪꜰʏ, ᴀɴᴅ sʜᴀʀᴇ ɪᴛ — ʙᴜᴛ ʏᴏᴜ ᴍᴜsᴛ ᴀʟsᴏ ɢɪᴠᴇ ᴄʀᴇᴅɪᴛ ᴀɴᴅ ᴋᴇᴇᴘ ɪᴛ ᴜɴᴅᴇʀ ᴛʜᴇ ɢᴘʟ ʟɪᴄᴇɴsᴇ.


━━━━━━━━━━━━━━━━━━━━












