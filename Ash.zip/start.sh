pip install -r requirements.txt --no-cache-dir
python3 main.py
